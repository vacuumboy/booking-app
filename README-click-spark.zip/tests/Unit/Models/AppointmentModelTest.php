<?php

namespace Tests\Unit\Models;

use PHPUnit\Framework\TestCase;

class AppointmentModelTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_example(): void
    {
        $this->assertTrue(true);
    }
}
